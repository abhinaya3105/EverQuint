import java.util.Scanner;

public class MaxProfit {

    static int theatreTime = 5;
    static int pubTime = 4;
    static int commercialTime = 10;

    static int theatreProfit = 1500;
    static int pubProfit = 1000;
    static int commercialProfit = 2000;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter total available time");

        int n = sc.nextInt();

        int maxProfit = 0;

        int bestT = 0;
        int bestP = 0;
        int bestC = 0;

        for(int t=0; t*theatreTime<=n; t++){

            for(int p=0; p*pubTime<=n; p++){

                for(int c=0; c*commercialTime<=n; c++){

                    int time =
                            t*theatreTime +
                                    p*pubTime +
                                    c*commercialTime;

                    if(time <= n){

                        int profit =
                                t*theatreProfit +
                                        p*pubProfit +
                                        c*commercialProfit;

                        if(profit > maxProfit){

                            maxProfit = profit;

                            bestT = t;
                            bestP = p;
                            bestC = c;
                        }
                    }
                }
            }
        }

        System.out.println("Theatres : "+bestT);
        System.out.println("Pubs : "+bestP);
        System.out.println("Commercial : "+bestC);

        System.out.println("Maximum Profit = "+maxProfit);
    }
}