package com.everquint.everquintassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverquintassignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
