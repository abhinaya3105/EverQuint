package com.everquint.everquintassignment.Exception;

public class ValidationException extends RuntimeException {

    public ValidationException(String message){
        super(message);
    }

}
