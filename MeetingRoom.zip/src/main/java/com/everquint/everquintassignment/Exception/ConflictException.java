package com.everquint.everquintassignment.Exception;

public class ConflictException extends RuntimeException {

    public ConflictException(String message){
        super(message);
    }
}
