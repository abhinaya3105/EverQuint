package com.everquint.everquintassignment.Service;

import com.everquint.everquintassignment.Dto.RoomRequest;
import com.everquint.everquintassignment.Entity.RoomEntity;
import com.everquint.everquintassignment.Exception.ValidationException;
import com.everquint.everquintassignment.Repository.RoomRepository;
import org.springframework.stereotype.Service;

@Service
public class RoomService {
    private final RoomRepository roomRepository;

    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    public RoomEntity createRoom(RoomRequest request) {

        if(request.getCapacity() <= 0){
            throw new ValidationException("Capacity must be positive");
        }

        if(roomRepository.existsByNameIgnoreCase(request.getName())){
            throw new ValidationException("Room name already exists");
        }

        RoomEntity room = new RoomEntity();
        room.setName(request.getName());
        room.setCapacity(request.getCapacity());
        room.setFloor(request.getFloor());
        room.setAmenities(request.getAmenities());

        return roomRepository.save(room);
    }
}
