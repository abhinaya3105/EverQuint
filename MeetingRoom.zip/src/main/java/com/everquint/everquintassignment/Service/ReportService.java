package com.everquint.everquintassignment.Service;

import com.everquint.everquintassignment.Dto.RoomResponse;
import com.everquint.everquintassignment.Entity.BookingEntity;
import com.everquint.everquintassignment.Entity.RoomEntity;
import com.everquint.everquintassignment.Repository.BookingRepository;
import com.everquint.everquintassignment.Repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReportService {
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public ReportService(RoomRepository roomRepository,
                         BookingRepository bookingRepository) {

        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    public List<RoomResponse> getUtilization(
            LocalDateTime from,
            LocalDateTime to) {

        List<RoomEntity> rooms = roomRepository.findAll();

        List<RoomResponse> result = new ArrayList<>();

        for (RoomEntity room : rooms) {

            List<BookingEntity> bookings = bookingRepository.findAll();

            double bookedHours = 0;

            for (BookingEntity booking : bookings) {

                if (!booking.getRoomId().equals(room.getId())) continue;

                LocalDateTime start =
                        booking.getStartTime().isBefore(from) ? from : booking.getStartTime();

                LocalDateTime end =
                        booking.getEndTime().isAfter(to) ? to : booking.getEndTime();

                if (start.isBefore(end)) {

                    bookedHours +=
                            Duration.between(start, end).toMinutes() / 60.0;
                }
            }

            double totalBusinessHours =
                    Duration.between(from, to).toHours();

            double utilization =
                    bookedHours / totalBusinessHours;

            result.add(new RoomResponse(
                    room.getId(),
                    room.getName(),
                    bookedHours,
                    utilization
            ));
        }

        return result;
    }
}
