package com.everquint.everquintassignment.Service;

import com.everquint.everquintassignment.Dto.BookingRequest;
import com.everquint.everquintassignment.Entity.BookingEntity;
import com.everquint.everquintassignment.Entity.ReportEntity;
import com.everquint.everquintassignment.Exception.ConflictException;
import com.everquint.everquintassignment.Exception.ValidationException;
import com.everquint.everquintassignment.Repository.BookingRepository;
import com.everquint.everquintassignment.Repository.ReportRepository;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

@Service
public class BookingService {
    private final BookingRepository bookingRepository;
    private final ReportRepository idempotencyRepository;

    public BookingService(
            BookingRepository bookingRepository,
            ReportRepository idempotencyRepository) {

        this.bookingRepository = bookingRepository;
        this.idempotencyRepository = idempotencyRepository;
    }

    public BookingEntity createBooking(String key, BookingRequest request) {

        if (idempotencyRepository.existsById(key)) {
            return idempotencyRepository.findById(key).get().getBooking();
        }

        if (request.getStartTime().isAfter(request.getEndTime())) {
            throw new ValidationException("startTime must be before endTime");
        }

        Duration duration =
                Duration.between(request.getStartTime(), request.getEndTime());

        if (duration.toMinutes() < 15 || duration.toHours() > 4) {
            throw new ValidationException("Booking must be between 15 min and 4 hours");
        }

        List<BookingEntity> conflicts =
                bookingRepository.findConflicts(
                        request.getRoomId(),
                        request.getStartTime(),
                        request.getEndTime());

        if (!conflicts.isEmpty()) {
            throw new ConflictException("Booking overlaps existing booking");
        }

        BookingEntity booking = new BookingEntity();

        booking.setRoomId(request.getRoomId());
        booking.setTitle(request.getTitle());
        booking.setOrganizerEmail(request.getOrganizerEmail());
        booking.setStartTime(request.getStartTime());
        booking.setEndTime(request.getEndTime());
        booking.setStatus("CONFIRMED");

        bookingRepository.save(booking);

        ReportEntity keyObj = new ReportEntity(key, booking);

        idempotencyRepository.save(keyObj);

        return booking;
    }

}
