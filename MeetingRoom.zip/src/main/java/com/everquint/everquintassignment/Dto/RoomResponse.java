package com.everquint.everquintassignment.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RoomResponse {
    private Long roomId;

    private String roomName;

    private double totalBookingHours;

    private double utilizationPercent;
}
