package com.everquint.everquintassignment.Dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class BookingRequest {
    private Long roomId;

    @NotBlank
    private String title;

    @Email
    private String organizerEmail;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

}
