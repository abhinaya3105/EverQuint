package com.everquint.everquintassignment.Dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class RoomRequest {
    @NotBlank
    private String name;

    @Min(1)
    private int capacity;

    private int floor;

    private List<String> amenities;
}
