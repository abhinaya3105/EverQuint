package com.everquint.everquintassignment.Controller;

import com.everquint.everquintassignment.Dto.RoomRequest;
import com.everquint.everquintassignment.Entity.RoomEntity;
import com.everquint.everquintassignment.Service.RoomService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService){
        this.roomService = roomService;
    }

    @PostMapping
    public RoomEntity createRoom(@RequestBody RoomRequest request){
        return roomService.createRoom(request);
    }
}
