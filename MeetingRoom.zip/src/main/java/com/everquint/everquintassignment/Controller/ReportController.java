package com.everquint.everquintassignment.Controller;

import com.everquint.everquintassignment.Dto.RoomResponse;
import com.everquint.everquintassignment.Service.ReportService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/reports")

public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/room-utilization")
    public List<RoomResponse> getUtilization(
            @RequestParam LocalDateTime from,
            @RequestParam LocalDateTime to) {

        return reportService.getUtilization(from, to);
    }
}