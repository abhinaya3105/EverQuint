package com.everquint.everquintassignment.Controller;

import com.everquint.everquintassignment.Dto.BookingRequest;
import com.everquint.everquintassignment.Entity.BookingEntity;
import com.everquint.everquintassignment.Service.BookingService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")

public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService){
        this.bookingService = bookingService;
    }

    @PostMapping
    public BookingEntity createBooking(
            @RequestHeader("Key") String key,
            @RequestBody BookingRequest request){

        return bookingService.createBooking(key, request);
    }
}
