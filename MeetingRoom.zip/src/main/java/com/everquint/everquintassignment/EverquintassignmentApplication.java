package com.everquint.everquintassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverquintassignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverquintassignmentApplication.class, args);
	}

}
