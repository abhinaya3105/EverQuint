package com.everquint.everquintassignment.Repository;

import com.everquint.everquintassignment.Entity.ReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<ReportEntity,String> {
}
