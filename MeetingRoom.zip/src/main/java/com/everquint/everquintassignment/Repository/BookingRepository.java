package com.everquint.everquintassignment.Repository;

import com.everquint.everquintassignment.Entity.BookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<BookingEntity, Long> {

    @Query("""
            SELECT b FROM BookingEntity b
            WHERE b.roomId = :roomId
            AND b.status = 'CONFIRMED'
            AND b.startTime < :endTime
            AND b.endTime > :startTime
           """)
    List<BookingEntity> findConflicts(
            @Param("roomId") Long roomId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime
    );
}

