package com.everquint.everquintassignment.Repository;

import com.everquint.everquintassignment.Entity.RoomEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository extends JpaRepository<RoomEntity, Long> {

    boolean existsByNameIgnoreCase(String name);
}
