package com.everquint.everquintassignment.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookingEntity {


    @Id
    @GeneratedValue
    private Long id;

    private Long roomId;

    private String title;

    private String organizerEmail;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private String status;

}
