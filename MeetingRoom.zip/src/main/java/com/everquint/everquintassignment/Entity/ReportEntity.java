package com.everquint.everquintassignment.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReportEntity {
    @Id
    private String key;

    @OneToOne
    private BookingEntity booking;
}
