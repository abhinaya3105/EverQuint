import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-water-tank',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './water-tank.component.html',
  styleUrl: './water-tank.component.css'
})
export class WaterTankComponent {

   inputHeights: string = '';
     heights: number[] = [];
     totalWater: number = 0;

     calculateWater() {

        this.heights = this.inputHeights
          .split(',')
          .map(v => Number(v.trim()));

        this.totalWater = this.trap(this.heights);
      }

    trap(height: number[]): number {

      let left = 0;
      let right = height.length - 1;

      let leftMax = 0;
      let rightMax = 0;

      let water = 0;

      while (left < right) {

        if (height[left] < height[right]) {

          if (height[left] >= leftMax)
            leftMax = height[left];
          else
            water += leftMax - height[left];

          left++;

        } else {

          if (height[right] >= rightMax)
            rightMax = height[right];
          else
            water += rightMax - height[right];

          right--;
        }
      }

      return water;
    }
  }
