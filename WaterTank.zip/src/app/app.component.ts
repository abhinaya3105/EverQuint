import { Component } from '@angular/core';
import { WaterTankComponent } from './water-tank/water-tank.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [WaterTankComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

}
